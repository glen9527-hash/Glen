
import streamlit as st
import requests
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="Crypto 合约分析", layout="wide")
st.title("📈 AI 加密货币行情分析")

symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
symbol = st.selectbox("选择币种", symbols)
interval = "1h"

def fetch_binance_klines(symbol, interval="1h", limit=100):
    url = f"https://api.binance.com/api/v3/klines?symbol={symbol}&interval={interval}&limit={limit}"
    response = requests.get(url)
    data = response.json()
    df = pd.DataFrame(data, columns=[
        "Open time", "Open", "High", "Low", "Close", "Volume",
        "Close time", "Quote asset volume", "Number of trades",
        "Taker buy base asset volume", "Taker buy quote asset volume", "Ignore"
    ])
    df["Open time"] = pd.to_datetime(df["Open time"], unit="ms")
    df["Close"] = pd.to_numeric(df["Close"])
    return df[["Open time", "Close"]]

df = fetch_binance_klines(symbol, interval)
st.line_chart(df.set_index("Open time")["Close"])
st.caption("当前展示 Binance 合约 K线行情，后续将结合新闻与 AI 分析建议。")
